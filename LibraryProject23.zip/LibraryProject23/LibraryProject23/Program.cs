﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using LibraryProject23.Data;


var builder = WebApplication.CreateBuilder(args);


var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddRazorPages();

builder.Services.AddAuthentication()
   .AddGoogle(googleOptions =>
   {
       googleOptions.ClientId = "756316020095-qh5lnm3f6gjhfj3s7348kn3utqjrgkuh.apps.googleusercontent.com"; //configuration["Authentication:Google:ClientId"];
       googleOptions.ClientSecret = "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"; //configuration["Authentication:Google:ClientSecret"];
   });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/Error");
 
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapRazorPages();

app.Run();

